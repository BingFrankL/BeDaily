# Quotidian

![Preview 1](https://raw.githubusercontent.com/swillsea/DailyDiary/d18bf4becd6ac30416a08086671b9a00316a7b4e/Demo/Demo.gif)

[![Language](https://img.shields.io/badge/language-Swift%202.2-orange.svg)](https://swift.org)
[![Platforms](https://img.shields.io/badge/platform-iOS-lightgrey.svg)](https://itunes.apple.com/us/app/quotidian-everyday-journal/id1118992581?ls=1&mt=8)
[![License](https://img.shields.io/github/license/JakeLin/SaveTheDot.svg?style=flat)](https://github.com/JakeLin/SaveTheDot/blob/master/LICENSE)

[Available on the App Store.](https://itunes.apple.com/us/app/quotidian-everyday-journal/id1118992581?ls=1&mt=8)

Quotidian was developed off the back of an earlier project, which [you can find here.](https://github.com/michaelmerrill/Instaclone)
