//
//  EntriesVC.swift
//  Quotidian
//
//  Created by Sam on 5/9/16.
//  Copyright © 2016 Sam Willsea, Pei Xiong, and Michael Merrill. All rights reserved.
//

import UIKit
import CoreData


class EntriesVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, NSFetchedResultsControllerDelegate{
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layoutButton: UIBarButtonItem!
    var viewIsListLayout = true
    let moc = (UIApplication.shared.delegate as! AppDelegate).managedObjectContext
    var entryResultsController: NSFetchedResultsController!
    var resultsArray : [NSManagedObject]!
    var sectionChanges = NSMutableArray()
    var itemChanges = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        UIApplication.shared.setStatusBarHidden(false, with:UIStatusBarAnimation.none)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        prepareForCollectionView()
        self.collectionView.reloadData()
    }
    
    func prepareForCollectionView() {
        entryResultsController = CoreDataManager.sharedInstance.fetchCoreData()
        entryResultsController.delegate = self
        resultsArray = entryResultsController.fetchedObjects! as! [NSManagedObject]
        self.collectionView.contentInset = UIEdgeInsetsMake(10, 0, 0, 0);
    }
    
    
// MARK: CollectionViewLayout
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (resultsArray != nil) { return resultsArray.count }
        else { return 0 }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var collectionViewWidth : CGFloat = 30.0
        if collectionView.frame.size.width > 30 {
            collectionViewWidth = self.collectionView.frame.size.width //we need to use a constant so that in viewWillAppear the status bar changing doesn't cause layout problems when reloading collectionView
        }
        if viewIsListLayout {
            return CGSize(width: (collectionViewWidth-20), height: 75)
        } else {
            return CGSize(width: collectionViewWidth/2, height: collectionViewWidth/2)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if viewIsListLayout {
            return 10
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if viewIsListLayout {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "listCell", for: indexPath) as! ListCell
            cell.entry = entryResultsController.object(at: indexPath) as? Entry
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "gridCell", for: indexPath) as! GridCell
            cell.entry = entryResultsController.object(at: indexPath) as? Entry
            return cell
        }
    }
    
    @IBAction func onLayoutButtonPressed(_ sender: UIBarButtonItem) {
        
        if (viewIsListLayout) {
            self.layoutButton.image = UIImage.init(named:"list")
            self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0)
            viewIsListLayout = false
        } else {
            self.layoutButton.image = UIImage.init(named:"grid")
            self.collectionView.contentInset = UIEdgeInsetsMake(10, 0, 0, 0)
            self.collectionView.setContentOffset(CGPoint.init(x: 0, y: -10), animated: false)

            viewIsListLayout = true
        }
        
        self.collectionView.reloadData()        
    }
    
//MARK: Required to use NSFetchedResultsController with UICollectionView
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange
        sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex
        sectionIndex: Int, for
        type: NSFetchedResultsChangeType) {
        
        let change = NSMutableDictionary()
        change.setObject(sectionIndex, forKey:"type")
        sectionChanges.add(change)
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>,
                    didChange anObject: Any,
                       at indexPath: IndexPath?,
                          for type: NSFetchedResultsChangeType,
                                newIndexPath: IndexPath?) {
        
        let change = NSMutableDictionary()
        
        switch type {
        case NSFetchedResultsChangeType.insert:
            change.setObject(newIndexPath!, forKey:"type")
            break;
        case NSFetchedResultsChangeType.delete:
            change.setObject(indexPath!, forKey:"type")
            break;
        case NSFetchedResultsChangeType.update:
            change.setObject(indexPath!, forKey:"type")
            break;
        case NSFetchedResultsChangeType.move:
            change.setObject([indexPath!, newIndexPath!], forKey:"type")
            break;
        }
        itemChanges .add(change)
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.collectionView.performBatchUpdates({
            
            for change in self.sectionChanges {
                change.enumerateKeysAndObjects({ (key, obj, stop) in
                    switch key {
                    case NSFetchedResultsChangeType.insert:
                        self.collectionView.insertSections(IndexSet.init(obj as! IndexSet))
                        break;
                    case NSFetchedResultsChangeType.delete:
                        self.collectionView.deleteSections(IndexSet.init(obj as! IndexSet))
                        break;
                    default:
                        break;
                    }
                })
            }
            
            for change in self.itemChanges {
                change.enumerateKeysAndObjects({ (key, obj, stop) in
                    switch key {
                    case NSFetchedResultsChangeType.insert:
                        self.collectionView.insertItems(at: [obj as! IndexPath])
                        break;
                    case NSFetchedResultsChangeType.delete:
                        self.collectionView.deleteItems(at: [obj as! IndexPath])
                        break;
                    case NSFetchedResultsChangeType.update:
                        self.collectionView.reloadItems(at: [obj as! IndexPath])
                        break;
                    case NSFetchedResultsChangeType.move:
                        self.collectionView.moveItem(at: obj.objectAtIndex(0) as! IndexPath, to: obj.objectAtIndex(1) as! IndexPath)
                        break;
                    default:
                        break;
                    }
                })
            }
            
        }) { (Bool) in
            self.sectionChanges.removeAllObjects()
            self.itemChanges.removeAllObjects()
        }
    }
    
// MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toAddNew" {
            let destVC = segue.destination as! AddOrEditVC // since we're going to a navigation controller
            destVC.moc = self.moc
            
        } else if segue.identifier == "toDayView" {
            let destVC = segue.destination as! DayByDayVC
            destVC.resultsArray = resultsArray
            let indexpath = self.collectionView.indexPathsForSelectedItems![0]
            //let entry = resultsArray[indexpath.row] as! Entry
            destVC.index = indexpath.row
            destVC.moc = self.moc
        }
    }
}
