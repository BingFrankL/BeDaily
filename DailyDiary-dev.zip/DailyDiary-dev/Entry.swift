//
//  Entry.swift
//  Quotidian
//
//  Created by Sam on 5/30/16.
//  Copyright © 2016 Sam Willsea. All rights reserved.
//

import Foundation
import CoreData


class Entry: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
